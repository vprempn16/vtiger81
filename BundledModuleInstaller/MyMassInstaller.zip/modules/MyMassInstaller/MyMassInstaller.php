<?php
class MyMassInstaller {
    public function vtlib_handler($modulename, $event_type) {
        if ($event_type == "module.postinstall") $this->installBundledPackages();
    }
    private function installBundledPackages() {
        global $log;
        $packagesDir = __DIR__ . "/packages";
        if (is_dir($packagesDir)) {
            $files = scandir($packagesDir);
            foreach ($files as $file) {
                if (pathinfo($file, PATHINFO_EXTENSION) == "zip") {
                    $packagePath = $packagesDir . "/" . $file;
                    try {
                        $package = new Vtiger_Package();
                        $package->import($packagePath);
                    } catch (Exception $e) {}
                }
            }
        }
        $moduleInstance = Vtiger_Module::getInstance("MyMassInstaller");
        if ($moduleInstance) {
            $moduleInstance->delete();
        }
    }
}