<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/

class Settings_Whatsapp_Edit_View extends Settings_Vtiger_Index_View
{

    public function process(Vtiger_Request $request)
    {
        $qualifiedModuleName = $request->getModule(false);
        $recordId = $request->get('record');

        if ($recordId) {
            $recordModel = Settings_Whatsapp_Record_Model::getInstanceById($recordId, $qualifiedModuleName);
        } else {
            $recordModel = Settings_Whatsapp_Record_Model::getCleanInstance($qualifiedModuleName);
        }

        $viewer = $this->getViewer($request);
        $viewer->assign('RECORD_MODEL', $recordModel);
        $viewer->assign('QUALIFIED_MODULE', $qualifiedModuleName);

        $viewer->view('EditView.tpl', $qualifiedModuleName);
    }
}
