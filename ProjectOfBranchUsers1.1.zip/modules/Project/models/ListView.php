<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/

/**
 * ListView Model Class for Project module
 */
class Project_ListView_Model extends Vtiger_ListView_Model
{

	/**
	 * Apply strict private-line restriction at ListView query level.
	 * This keeps list visibility aligned with Detail/Edit/Save checks.
	 *
	 * @return string
	 */
	public function getQuery()
	{
		$listQuery = parent::getQuery();

		$hierarchyHelper = 'modules/BranchUsers/helpers/HierarchyAccess.php';
		if (!file_exists($hierarchyHelper)) {
			return $listQuery;
		}
		require_once $hierarchyHelper;
		$currentUser = vglobal('current_user');

		$hierarchyFragment = BranchUsers_HierarchyAccess::appendProjectPrivateLineSqlFragment(
			$currentUser,
			'vtiger_crmentity.smownerid',
			'vtiger_crmentity.smcreatorid'
		);


		// If hierarchy restriction exists, we need to allow mentions as an exception
		if (!empty($hierarchyFragment)) {
			$mentionHelper = 'modules/Project/helpers/MentionPermissionHelper.php';
			if (file_exists($mentionHelper)) {
				require_once $mentionHelper;
				$mentionedProjects = Project_MentionPermissionHelper::getMentionedProjects($currentUser->id);
				if (!empty($mentionedProjects)) {
					$mentionIds = implode(',', $mentionedProjects);
					// Strip the leading " AND " from hierarchy fragment to wrap it in our OR
					$hierarchyCondition = preg_replace('/^\s*AND\s+/i', '', $hierarchyFragment);
					$listQuery .= " AND ( $hierarchyCondition OR vtiger_crmentity.crmid IN ($mentionIds) ) ";
				} else {
					$listQuery .= $hierarchyFragment;
				}
			} else {
				$listQuery .= $hierarchyFragment;
			}
		}

		return $listQuery;
	}

	/**
	 * Function to get the list of listview links
	 * @param <Array> $linkParams Parameters to be replaced in the link template
	 * @return <Array> - an array of Vtiger_Link_Model instances
	 */
	public function getListViewLinks($linkParams)
	{
		$userPrivilegesModel = Users_Privileges_Model::getCurrentUserPrivilegesModel();
		$links = parent::getListViewLinks($linkParams);
		$quickLinks = array();

		$projectTaskInstance = Vtiger_Module_Model::getInstance('ProjectTask');
		if ($userPrivilegesModel->hasModulePermission($projectTaskInstance->getId())) {
			$quickLinks[] = array(
				'linktype' => 'LISTVIEWQUICK',
				'linklabel' => 'Tasks List',
				'linkurl' => $this->getModule()->getDefaultUrl(),
				'linkicon' => ''
			);
		}

		foreach ($quickLinks as $quickLink) {
			$links['LISTVIEWQUICK'][] = Vtiger_Link_Model::getInstanceFromValues($quickLink);
		}

		return $links;
	}

}