<?php 
include_once( "modules/Emails/class.smtp.php" );
include_once( "modules/Emails/class.phpmailer.php" );
require_once 'vtlib/Vtiger/Mailer.php';
class CommentMentionSendMail extends VTEventHandler {

	/**
	 * Check if mentioned user is in hierarchy below the current user (lower level)
	 * @param int $mentionedUserId
	 * @param int $currentUserId
	 * @return bool - true if mentioned user is below current user
	 */
	function isUserBelowInHierarchy($mentionedUserId, $currentUserId) {
		$mentionedUserId = (int)$mentionedUserId;
		$currentUserId = (int)$currentUserId;
		
		if ($mentionedUserId <= 0 || $currentUserId <= 0) {
			return false;
		}
		
		// Check if BranchUsers hierarchy system exists
		$helper = 'modules/BranchUsers/helpers/HierarchyAccess.php';
		if (file_exists($helper)) {
			require_once $helper;
			// Check if current user is ancestor of mentioned user (mentioned is below)
			return BranchUsers_HierarchyAccess::isAncestorOrSelf($currentUserId, $mentionedUserId);
		}
		
		// Fallback to Vtiger role hierarchy
		global $adb;
		$currentRoleQuery = $adb->pquery("SELECT roleid FROM vtiger_user2role WHERE userid = ?", array($currentUserId));
		$mentionedRoleQuery = $adb->pquery("SELECT roleid FROM vtiger_user2role WHERE userid = ?", array($mentionedUserId));
		
		if ($adb->num_rows($currentRoleQuery) > 0 && $adb->num_rows($mentionedRoleQuery) > 0) {
			$currentRole = $adb->query_result($currentRoleQuery, 0, 'roleid');
			$mentionedRole = $adb->query_result($mentionedRoleQuery, 0, 'roleid');
			
			// Get role hierarchy
			$currentRoleHierarchy = $adb->pquery("SELECT parentrole FROM vtiger_role WHERE roleid = ?", array($currentRole));
			$mentionedRoleHierarchy = $adb->pquery("SELECT parentrole FROM vtiger_role WHERE roleid = ?", array($mentionedRole));
			
			if ($adb->num_rows($currentRoleHierarchy) > 0 && $adb->num_rows($mentionedRoleHierarchy) > 0) {
				$currentParentRole = $adb->query_result($currentRoleHierarchy, 0, 'parentrole');
				$mentionedParentRole = $adb->query_result($mentionedRoleHierarchy, 0, 'parentrole');
				
				// Check if current role is parent of mentioned user's role
				return strpos($mentionedParentRole, $currentParentRole) === 0 && $currentParentRole !== $mentionedParentRole;
			}
		}
		
		return false;
	}

	/**
	 * Check if mentioned user is in same hierarchy level as current user
	 * @param int $mentionedUserId
	 * @param int $currentUserId
	 * @return bool - true if mentioned user is in same hierarchy level
	 */
	function isUserInSameHierarchy($mentionedUserId, $currentUserId) {
		$mentionedUserId = (int)$mentionedUserId;
		$currentUserId = (int)$currentUserId;
		
		if ($mentionedUserId <= 0 || $currentUserId <= 0) {
			return false;
		}
		
		// Check if they're the same user
		if ($mentionedUserId === $currentUserId) {
			return true;
		}
		
		// Check if BranchUsers hierarchy system exists
		$helper = 'modules/BranchUsers/helpers/HierarchyAccess.php';
		if (file_exists($helper)) {
			require_once $helper;
			// Get ancestor chains for both users
			$mentionedAncestors = BranchUsers_HierarchyAccess::getAncestorChainUserIds($mentionedUserId);
			$currentAncestors = BranchUsers_HierarchyAccess::getAncestorChainUserIds($currentUserId);
			
			// Check if they share the same branch root
			if (!empty($mentionedAncestors) && !empty($currentAncestors)) {
				$mentionedRoot = end($mentionedAncestors);
				$currentRoot = end($currentAncestors);
				return $mentionedRoot === $currentRoot;
			}
		}
		
		// Fallback to Vtiger role hierarchy
		global $adb;
		$currentRoleQuery = $adb->pquery("SELECT roleid FROM vtiger_user2role WHERE userid = ?", array($currentUserId));
		$mentionedRoleQuery = $adb->pquery("SELECT roleid FROM vtiger_user2role WHERE userid = ?", array($mentionedUserId));
		
		if ($adb->num_rows($currentRoleQuery) > 0 && $adb->num_rows($mentionedRoleQuery) > 0) {
			$currentRole = $adb->query_result($currentRoleQuery, 0, 'roleid');
			$mentionedRole = $adb->query_result($mentionedRoleQuery, 0, 'roleid');
			
			// Get role hierarchy
			$mentionedRoleHierarchy = $adb->pquery("SELECT parentrole FROM vtiger_role WHERE roleid = ?", array($mentionedRole));
			$currentRoleHierarchy = $adb->pquery("SELECT parentrole FROM vtiger_role WHERE roleid = ?", array($currentRole));
			
			if ($adb->num_rows($mentionedRoleHierarchy) > 0 && $adb->num_rows($currentRoleHierarchy) > 0) {
				$mentionedParentRole = $adb->query_result($mentionedRoleHierarchy, 0, 'parentrole');
				$currentParentRole = $adb->query_result($currentRoleHierarchy, 0, 'parentrole');
				
				// Check if they have the same top-level role
				$mentionedTopRole = explode('::', $mentionedParentRole)[0];
				$currentTopRole = explode('::', $currentParentRole)[0];
				return $mentionedTopRole === $currentTopRole;
			}
		}
		
		return false;
	}

	/**
	 * Check if user can edit project based on mention hierarchy permissions
	 * @param int $projectId
	 * @param int $userId
	 * @return bool - true if user can edit project
	 */
	function canUserEditProjectByMention($projectId, $userId) {
		$projectId = (int)$projectId;
		$userId = (int)$userId;
		
		if ($projectId <= 0 || $userId <= 0) {
			return false;
		}
		
		// Check session permissions first
		if (isset($_SESSION['project_mention_permissions'][$projectId][$userId])) {
			$permission = $_SESSION['project_mention_permissions'][$projectId][$userId];
			if ($permission['expires'] > time()) {
				return $permission['can_edit'];
			} else {
				// Remove expired permission
				unset($_SESSION['project_mention_permissions'][$projectId][$userId]);
			}
		}
		
		// Check database for recent mention permissions
		global $adb;
		$recentMentions = $adb->pquery(
			"SELECT description FROM vtiger_vdnotifierpro 
			 WHERE userid = ? AND crmid IN (
				 SELECT commentid FROM vtiger_modcomments WHERE related_to = ?
			 ) AND action = 'MENTION' AND modifiedtime > DATE_SUB(NOW(), INTERVAL 1 HOUR)
			 ORDER BY modifiedtime DESC LIMIT 1",
			array($userId, $projectId)
		);
		
		if ($adb->num_rows($recentMentions) > 0) {
			$description = $adb->query_result($recentMentions, 0, 'description');
			$metadata = json_decode($description, true);
			if ($metadata && isset($metadata['can_edit_project'])) {
				return $metadata['can_edit_project'];
			}
		}
		
		return false;
	}

	function handleEvent($eventName, $data) {
		if($eventName == 'vtiger.entity.beforesave') {
		}
		if($eventName == 'vtiger.entity.aftersave') {
			// Entity has been saved, take next action
			$moduleName = $data->getModuleName();
			

			if ($moduleName == 'ModComments') {
				global $current_user,$adb,$site_URL;
				
				// Construct mock request for event trigger where $request is undefined
				$request = new Vtiger_Request(array('module' => 'VTAtomCommentsMentions'));
				$isMailSendPermission = $this->isMailSendPermission('comment_mentions');
				

				if($isMailSendPermission){
					$commentcontent	= $data->get('commentcontent');
					

					// Use regex to find all @mentions in the comment
					$usernames = array();
					preg_match_all('/@([^\s]+)/', $commentcontent, $matches);
					if (!empty($matches[1])) {
						$usernames = $matches[1];
						// Clean up usernames - remove any trailing punctuation
						$usernames = array_map(function($username) {
							return rtrim($username, '.,!?;:');
						}, $usernames);
					}
					$related_to = $data->get('related_to');
					$relatedmodule = getSalesEntityType($related_to);
					$additional_content = "This is your record detail.<br>";
					$additional_content .= 'Click <a href='.$site_URL.'index.php?module='.$relatedmodule.'&relatedModule='.$moduleName.'&view=Detail&record='.$related_to.'&mode=showRelatedList&relationId='.$data->getID().'&tab_label='.$moduleName.'&app=MARKETING&commentid='.$data->getID().'>here</a> to view.';
					$commentcontent = $commentcontent . "<br><br>" . $additional_content;
					foreach($usernames as $key => $username){
						$userdetails = $this->getUserDetailsByUsername($username);
						
						// VDNotifierPro Notification logic with hierarchy-based permissions
						$userId = isset($userdetails['id']) ? $userdetails['id'] : false;
						
						if (file_exists('modules/VDNotifierPro/models/Record.php') && vtlib_isModuleActive('VDNotifierPro') && $userId) {
							require_once 'modules/VDNotifierPro/models/Record.php';
							
							// Check hierarchy relationship between mentioned user and current user
							$isBelow = $this->isUserBelowInHierarchy($userId, $current_user->id);
							$isSameHierarchy = $this->isUserInSameHierarchy($userId, $current_user->id);
							
							// Determine notification title and permissions based on hierarchy
							$notificationTitle = "Mentioned you in a comment";
							$canEditProject = false;
							
							if ($isBelow) {
								// Mentioned user is below in hierarchy - can only comment
								$notificationTitle = "Mentioned you in a comment (View & Comment Only)";
								$canEditProject = false;
							} elseif ($isSameHierarchy) {
								// Mentioned user is in same hierarchy - can edit project and comment
								$notificationTitle = "Mentioned you in a comment (Project Edit Access)";
								$canEditProject = true;
							} else {
								// Outside hierarchy - view and comment only
								$notificationTitle = "Mentioned you in a comment (View & Comment Only)";
								$canEditProject = false;
							}
							
							$VDNotifier = new VDNotifierPro_Record_Model();
							$VDNotifier->userid = $userId;
							$VDNotifier->modulename = 'ModComments';
							$VDNotifier->crmid = $data->getId(); 
							$VDNotifier->modiuserid = $current_user->id; 
							$VDNotifier->action = 'MENTION';
							$VDNotifier->modifiedtime = date('Y-m-d H:i:s');
							$VDNotifier->title = $notificationTitle;
							$VDNotifier->link = "module=" . $relatedmodule . "&view=Detail&record=" . $related_to;
							
							// Store hierarchy permission info in notification metadata
							$VDNotifier->description = json_encode([
								'can_edit_project' => $canEditProject,
								'hierarchy_level' => $isBelow ? 'below' : ($isSameHierarchy ? 'same' : 'external'),
								'mentioned_by' => $current_user->id,
								'related_module' => $relatedmodule,
								'related_record' => $related_to
							]);
							
							$VDNotifier->save();
							
							// Store permission in session for project edit checks
							if ($relatedmodule === 'Project') {
								$_SESSION['project_mention_permissions'][$related_to][$userId] = [
									'can_edit' => $canEditProject,
									'expires' => time() + 3600 // 1 hour expiry
								];
							}
						}

						$toEmail = $userdetails['email'];
						$isMailSendPermission = $this->isMailSendPermission('send_commentmail');
						if($toEmail != '' && $isMailSendPermission){
							$fullname = $userdetails['first_name'] . ' ' . $userdetails['last_name'];
							$commentcontent_with_name = str_replace("@$username", "@$fullname", $commentcontent);
							
							try{
								$mail = new PHPMailer(true);
								$mail->SMTPDebug = 2;
								$mail->isSMTP();
								$mail->Host  = 'smtp.gmail.com;';
								$mail->SMTPAuth = true;
								$mail->Username = 'sureshm@atomlines.com';
								$mail->Password = "izborfinocgsqdfz";
								$mail->SMTPSecure = 'tls';
								$mail->Port  = 587;
								$mail->setFrom('sureshm@atomlines.com', 'prem');
								$mail->addAddress($toEmail);
								$mail->isHTML(true);
								$mail->Subject = 'EmailFunction';
								$mail->Body = $commentcontent_with_name;
								$mail->AltBody = 'Body in plain text for non-HTML mail clients';
								$result = $mail->send();
							}
							catch (Exception $e){
								echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
							}
						}
					}
				}

			}
		}
	}
	function isMailSendPermission($type){
		global $adb;
		$res = $adb->pquery("SELECT * FROM atom_vtcommenton_rel WHERE type = ?",array($type));
		if($adb->num_rows($res) > 0){
			if($adb->query_result($res,0,'is_checked') == 'on'){
				$return = true;
			}else{
				$return = false;
			}
		}
		return $return;
	}
	function getUserDetailsByUsername($username){
		global $current_user,$adb;
		$email = '';
		if($username != ''){
			$usermailquery = $adb->pquery('SELECT id, email1,first_name,last_name FROM vtiger_users WHERE user_name=?',array($username));
			$return['id'] = $adb->query_result($usermailquery,0,'id');
			$return['email'] = $adb->query_result($usermailquery,0,'email1');
			$return['first_name'] =  $adb->query_result($usermailquery,0,'first_name');
			$return['last_name'] = $adb->query_result($usermailquery,0,'last_name');
		}
		return $return;
	}
}
?>
